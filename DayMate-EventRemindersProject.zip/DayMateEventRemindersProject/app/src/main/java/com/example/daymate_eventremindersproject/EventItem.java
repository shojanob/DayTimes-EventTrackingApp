package com.example.daymate_eventremindersproject;



public class EventItem {
    public long id;
    public String title;
    public long dateEpoch;
    public Long timeEpoch;
    public String desc;
}

