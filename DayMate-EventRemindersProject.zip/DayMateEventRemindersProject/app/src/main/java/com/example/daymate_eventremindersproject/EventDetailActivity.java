package com.example.daymate_eventremindersproject;


import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;

public class EventDetailActivity extends AppCompatActivity {
    private DbHelper db;
    private EditText etTitle, etDateMillis, etTimeMillis, etDesc;
    private long eventId = -1;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_event_detail);
        db = new DbHelper(this);

        etTitle = findViewById(R.id.etTitle);
        etDateMillis = findViewById(R.id.etDate);   // for course simplicity: input millis or use a DatePicker in UI
        etTimeMillis = findViewById(R.id.etTime);   // optional; allow blank
        etDesc = findViewById(R.id.etDescription);

        if (getIntent().hasExtra("eventId")) {
            eventId = getIntent().getLongExtra("eventId", -1);
            // In a fuller version you'd load row & pre-fill; omitted for brevity
        }

        Button btnSave = findViewById(R.id.btnSave);
        Button btnCancel = findViewById(R.id.btnCancel);

        btnCancel.setOnClickListener(v -> finish());
        btnSave.setOnClickListener(v -> save());
    }

    private void save() {
        String title = etTitle.getText().toString().trim();
        String dateStr = etDateMillis.getText().toString().trim();
        String timeStr = etTimeMillis.getText().toString().trim();
        String desc = etDesc.getText().toString().trim();

        if (TextUtils.isEmpty(title) || TextUtils.isEmpty(dateStr)) {
            toast("Title and dateMillis are required"); return;
        }
        long dateEpoch = Long.parseLong(dateStr);
        Long timeEpoch = TextUtils.isEmpty(timeStr) ? null : Long.parseLong(timeStr);

        if (eventId == -1) {
            long id = db.insertEvent(title, dateEpoch, timeEpoch, desc);
            if (id != -1) {
                scheduleDayOfAlert(id, title, dateEpoch);
                toast("Saved"); finish();
            } else toast("Insert failed");
        } else {
            int n = db.updateEvent(eventId, title, dateEpoch, timeEpoch, desc);
            if (n > 0) {
                scheduleDayOfAlert(eventId, title, dateEpoch);
                toast("Updated"); finish();
            } else toast("Update failed");
        }
    }

    private void scheduleDayOfAlert(long eventId, String title, long dateEpoch) {
        // Schedule at 9:00 AM local on that date
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(dateEpoch);
        cal.set(Calendar.HOUR_OF_DAY, 9);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        long triggerAt = cal.getTimeInMillis();

        Intent intent = new Intent(this, EventAlarmReceiver.class);
        intent.putExtra("eventId", eventId);
        intent.putExtra("title", title);
        PendingIntent pi = PendingIntent.getBroadcast(
                this, (int) eventId, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
    }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }
}

