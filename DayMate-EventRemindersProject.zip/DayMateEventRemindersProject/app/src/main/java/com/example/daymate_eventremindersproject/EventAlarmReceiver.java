package com.example.daymate_eventremindersproject;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.Manifest;
import android.telephony.SmsManager;
import android.widget.Toast;
import androidx.core.content.ContextCompat;
import android.content.pm.PackageManager;

public class EventAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context ctx, Intent intent) {
        long eventId = intent.getLongExtra("eventId", -1);
        String title = intent.getStringExtra("title");
        // In a fuller version, look up the current logged-in user’s phone.
        // For demo: fetch a single saved phone from the first user or SharedPreferences.
        DbHelper db = new DbHelper(ctx);
        String phone = db.getUserPhone(/* username if you store it; else fallback */ ""); // handle nulls

        int perm = ContextCompat.checkSelfPermission(ctx, Manifest.permission.SEND_SMS);
        if (perm == PackageManager.PERMISSION_GRANTED && phone != null && !phone.isEmpty()) {
            try {
                SmsManager.getDefault().sendTextMessage(phone, null,
                        "Reminder: " + title + " is scheduled for today.", null, null);
                Toast.makeText(ctx, "SMS sent", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(ctx, "SMS failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        } else {
            // Permission denied or no phone → silently skip SMS; app continues to function
            Toast.makeText(ctx, "SMS not permitted or phone missing", Toast.LENGTH_SHORT).show();
        }
    }
}
