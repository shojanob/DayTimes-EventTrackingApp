package com.example.daymate_eventremindersproject;


import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import java.util.Calendar;

public class EventDetailRescheduler {
    public static void schedule(Context ctx, long eventId, String title, long dateEpoch) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(dateEpoch);
        cal.set(Calendar.HOUR_OF_DAY, 9);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);

        Intent intent = new Intent(ctx, EventAlarmReceiver.class);
        intent.putExtra("eventId", eventId);
        intent.putExtra("title", title);
        PendingIntent pi = PendingIntent.getBroadcast(
                ctx, (int) eventId, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
    }
}

