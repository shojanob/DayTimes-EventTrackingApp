package com.example.daymate_eventremindersproject;



import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context ctx, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            // Re-scan events and re-schedule any future alarms
            DbHelper db = new DbHelper(ctx);
            Cursor c = db.getAllEventsOrderByDate();
            try {
                while (c.moveToNext()) {
                    long id = c.getLong(c.getColumnIndexOrThrow(DbHelper.C_E_ID));
                    String title = c.getString(c.getColumnIndexOrThrow(DbHelper.C_E_TITLE));
                    long dateEpoch = c.getLong(c.getColumnIndexOrThrow(DbHelper.C_E_DATE_EPOCH));
                    // reuse scheduling logic by building an Intent to EventDetailActivity’s helper
                    // For brevity, duplicate small calculation here or factor into a Util.
                    EventDetailRescheduler.schedule(ctx, id, title, dateEpoch);
                }
            } finally { c.close(); }
        }
    }
}

