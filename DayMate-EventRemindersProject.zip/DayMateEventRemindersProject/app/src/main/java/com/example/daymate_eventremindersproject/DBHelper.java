package com.example.daymate_eventremindersproject;

import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.database.Cursor;

public class DbHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "app.db";
    private static final int DB_VERSION = 1;

    // Users
    public static final String T_USERS = "users";
    public static final String C_U_USERNAME = "username";
    public static final String C_U_PWHASH = "password_hash";
    public static final String C_U_PHONE = "phone"; // optional for SMS target

    // Events
    public static final String T_EVENTS = "events";
    public static final String C_E_ID = "id";
    public static final String C_E_TITLE = "title";
    public static final String C_E_DATE_EPOCH = "dateEpoch"; // millis @ 00:00 or exact
    public static final String C_E_TIME_EPOCH = "timeEpoch"; // millis within day (optional)
    public static final String C_E_DESC = "description";

    public DbHelper(Context ctx) {
        super(ctx, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + T_USERS + " (" +
                C_U_USERNAME + " TEXT PRIMARY KEY, " +
                C_U_PWHASH + " TEXT NOT NULL, " +
                C_U_PHONE + " TEXT)");

        db.execSQL("CREATE TABLE IF NOT EXISTS " + T_EVENTS + " (" +
                C_E_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                C_E_TITLE + " TEXT NOT NULL, " +
                C_E_DATE_EPOCH + " INTEGER NOT NULL, " +
                C_E_TIME_EPOCH + " INTEGER, " +
                C_E_DESC + " TEXT)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        // no-op for course; add ALTER TABLE migrations if you bump DB_VERSION
    }

    // ---- Users ----
    public boolean createUser(String username, String passwordHash, String phone) {
        ContentValues cv = new ContentValues();
        cv.put(C_U_USERNAME, username);
        cv.put(C_U_PWHASH, passwordHash);
        cv.put(C_U_PHONE, phone);
        long res = getWritableDatabase().insert(T_USERS, null, cv);
        return res != -1;
    }

    public String getPasswordHash(String username) {
        Cursor c = getReadableDatabase().query(T_USERS,
                new String[]{C_U_PWHASH}, C_U_USERNAME + "=?",
                new String[]{username}, null, null, null);
        try {
            if (c.moveToFirst()) return c.getString(0);
            return null;
        } finally { c.close(); }
    }

    public String getUserPhone(String username) {
        Cursor c = getReadableDatabase().query(T_USERS,
                new String[]{C_U_PHONE}, C_U_USERNAME + "=?",
                new String[]{username}, null, null, null);
        try {
            if (c.moveToFirst()) return c.getString(0);
            return null;
        } finally { c.close(); }
    }

    // ---- Events (CRUD) ----
    public long insertEvent(String title, long dateEpoch, Long timeEpoch, String desc) {
        ContentValues cv = new ContentValues();
        cv.put(C_E_TITLE, title);
        cv.put(C_E_DATE_EPOCH, dateEpoch);
        if (timeEpoch != null) cv.put(C_E_TIME_EPOCH, timeEpoch);
        cv.put(C_E_DESC, desc);
        return getWritableDatabase().insert(T_EVENTS, null, cv);
    }

    public int updateEvent(long id, String title, long dateEpoch, Long timeEpoch, String desc) {
        ContentValues cv = new ContentValues();
        cv.put(C_E_TITLE, title);
        cv.put(C_E_DATE_EPOCH, dateEpoch);
        if (timeEpoch != null) cv.put(C_E_TIME_EPOCH, timeEpoch); else cv.putNull(C_E_TIME_EPOCH);
        cv.put(C_E_DESC, desc);
        return getWritableDatabase().update(T_EVENTS, cv, C_E_ID + "=?",
                new String[]{String.valueOf(id)});
    }

    public int deleteEvent(long id) {
        return getWritableDatabase().delete(T_EVENTS, C_E_ID + "=?",
                new String[]{String.valueOf(id)});
    }

    public Cursor getAllEventsOrderByDate() {
        return getReadableDatabase().query(T_EVENTS, null,
                null, null, null, null, C_E_DATE_EPOCH + " ASC");
    }
}


