package com.example.daymate_eventremindersproject;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private DbHelper db;
    private EditText etUser, etPass, etPhone; // optional phone for SMS

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_login);
        db = new DbHelper(this);

        etUser = findViewById(R.id.etUsername);
        etPass = findViewById(R.id.etPassword);
        // Add a small phone field in your layout or default to emulator phone.
        etPhone = findViewById(R.id.etPhoneOptional); // if you added it; else set null/blank safely

        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnCreate = findViewById(R.id.btnCreateAccount);

        btnLogin.setOnClickListener(v -> doLogin());
        btnCreate.setOnClickListener(v -> doCreate());
    }

    private void doLogin() {
        String u = safe(etUser), p = safe(etPass);
        if (u.isEmpty() || p.isEmpty()) {
            toast("Enter username and password");
            return;
        }
        String stored = db.getPasswordHash(u);
        if (stored == null) {
            toast("No account found. Tap Create new account.");
            return;
        }
        String hash = HashUtil.sha256(p);
        if (hash != null && hash.equals(stored)) {
            goToEvents(u);
        } else {
            toast("Invalid credentials");
        }
    }

    private void doCreate() {
        String u = safe(etUser), p = safe(etPass);
        String phone = etPhone != null ? etPhone.getText().toString().trim() : "";
        if (u.isEmpty() || p.isEmpty()) { toast("Enter username and password"); return; }
        if (db.getPasswordHash(u) != null) { toast("User already exists"); return; }
        boolean ok = db.createUser(u, HashUtil.sha256(p), phone);
        if (ok) { toast("Account created"); goToEvents(u); }
        else toast("Failed to create user");
    }

    private String safe(EditText e) { return e == null ? "" : e.getText().toString().trim(); }
    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    private void goToEvents(String username) {
        Intent i = new Intent(this, EventsActivity.class);
        i.putExtra("username", username);
        startActivity(i);
        finish();
    }
}
