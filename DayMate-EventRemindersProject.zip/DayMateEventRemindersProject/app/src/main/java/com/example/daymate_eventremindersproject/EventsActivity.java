package com.example.daymate_eventremindersproject;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.content.Intent;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class EventsActivity extends AppCompatActivity {
    private DbHelper db;
    private RecyclerView rv;
    private EventsAdapter adapter;
    private String username;

    private ActivityResultLauncher<Intent> editLauncher;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_events);

        username = getIntent().getStringExtra("username");
        db = new DbHelper(this);

        rv = findViewById(R.id.rvEvents);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new EventsAdapter();
        rv.setAdapter(adapter);

        FloatingActionButton fab = findViewById(R.id.fabAddEvent);
        fab.setOnClickListener(v -> {
            Intent i = new Intent(this, EventDetailActivity.class);
            editLauncher.launch(i);
        });

        editLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> refresh());

        refresh();
    }

    private void refresh() {
        ArrayList<EventItem> data = new ArrayList<>();
        Cursor c = db.getAllEventsOrderByDate();
        try {
            while (c.moveToNext()) {
                EventItem e = new EventItem();
                e.id = c.getLong(c.getColumnIndexOrThrow(DbHelper.C_E_ID));
                e.title = c.getString(c.getColumnIndexOrThrow(DbHelper.C_E_TITLE));
                e.dateEpoch = c.getLong(c.getColumnIndexOrThrow(DbHelper.C_E_DATE_EPOCH));
                int idx = c.getColumnIndex(DbHelper.C_E_TIME_EPOCH);
                e.timeEpoch = (idx >= 0 && !c.isNull(idx)) ? c.getLong(idx) : null;
                e.desc = c.getString(c.getColumnIndexOrThrow(DbHelper.C_E_DESC));
                data.add(e);
            }
        } finally { c.close(); }
        adapter.setData(data);
    }

    private class EventsAdapter extends RecyclerView.Adapter<EventsVH> {
        private ArrayList<EventItem> items = new ArrayList<>();
        void setData(ArrayList<EventItem> d) { items = d; notifyDataSetChanged(); }

        @NonNull @Override public EventsVH onCreateViewHolder(@NonNull ViewGroup p, int vType) {
            return new EventsVH(getLayoutInflater().inflate(R.layout.item_event, p, false));
        }
        @Override public void onBindViewHolder(@NonNull EventsVH h, int pos) {
            EventItem e = items.get(pos);
            h.title.setText(e.title);
            String when = new SimpleDateFormat("EEE, MMM d", Locale.getDefault())
                    .format(new Date(e.dateEpoch));
            h.dateTime.setText(when);
            h.btnEdit.setOnClickListener(v -> {
                Intent i = new Intent(EventsActivity.this, EventDetailActivity.class);
                i.putExtra("eventId", e.id);
                editLauncher.launch(i);
            });
            h.btnDelete.setOnClickListener(v -> {
                db.deleteEvent(e.id);
                refresh();
            });
        }
        @Override public int getItemCount() { return items.size(); }
    }

    private static class EventsVH extends RecyclerView.ViewHolder {
        TextView title, dateTime;
        Button btnEdit, btnDelete;
        EventsVH(android.view.View v) {
            super(v);
            title = v.findViewById(R.id.tvEventTitle);
            dateTime = v.findViewById(R.id.tvEventDateTime);
            btnEdit = v.findViewById(R.id.btnEdit);
            btnDelete = v.findViewById(R.id.btnDelete);
        }
    }

    private static final int REQ_SMS = 101;

    private void ensureSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQ_SMS);
        } else {
            // already granted; you can enable your SMS toggle UI
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] perms, int[] res) {
        super.onRequestPermissionsResult(requestCode, perms, res);
        if (requestCode == REQ_SMS) {
            // If granted → enable SMS; else leave disabled (app still works)
        }
    }

}

